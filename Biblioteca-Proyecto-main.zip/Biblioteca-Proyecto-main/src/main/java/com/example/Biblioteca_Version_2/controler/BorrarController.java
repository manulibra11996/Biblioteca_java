package com.example.Biblioteca_Version_2.controler;

import com.example.Biblioteca_Version_2.entities.Socios
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@BorrarController
@RequestMapping("/Socios")
public class SociosControllers {@Autowiredprivate Socios
        Socios;@GetMapping("/delete/{id}")public String
showDeleteConfirmation(@PathVariable Long id, org.springframework.ui.Model model)
{model.addAttribute("entity", Socios.findById(id));return "delete-confirmation";
// Thymeleaf template name}@PostMapping("/delete/{id}")public String
    deleteEntity(@PathVariable Long id, RedirectAttributes redirectAttributes) {Socios.deleteById(id);redirectAttributes.addFlashAttribute("message", "Entity
        deleted successfully!");return "redirect:/Socios/list"; // Redirect to the list page
    after deletion}
}
