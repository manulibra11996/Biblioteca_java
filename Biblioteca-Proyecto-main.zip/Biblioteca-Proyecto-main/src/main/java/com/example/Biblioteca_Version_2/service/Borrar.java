package com.example.Biblioteca_Version_2.service;

import com.example.Biblioteca_Version_2.entities.Socios;
import com.example.Biblioteca_Version_2.repositories.SociosRepositories;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Borrar
public class Borrar {@Autowiredprivate SociosRepositories
        SociosRepositories;public Socios findById(Long id) {return
        SociosRepositories.findById(id).orElseThrow(() -> new RuntimeException("Entity not
                found"));}public void deleteById(Long id) {SociosRepositories.deleteById(id);}
}